# RAR Paper Deck — Plan

Audience: students new to the topic, professor reviewing. Long deep dive, ~26 slides, 25 min.
Style: Clean academic — navy / teal / gray / orange, matching the paper's own matplotlib charts.
Fonts: Source Serif 4 (headlines), IBM Plex Sans (body/labels).

## Palette
--navy #131B2E (divider/title bg), --navy2 #1B2A4A
--paper #F7F5EF (content bg), --ink #1A1F2B, --ink-soft #5B6270
--teal #1E8A72 (RAR/positive), --teal-dark #146354
--gray #8B8F98 (baseline/neutral), --orange #D97F35 (Vector RAG / caution / negative-result accent)
--line #E3DFD3

## Title sequence (topic-style, parallel)
1. Title — Recursive Autonomous Research
2. Roadmap & The Big Picture (agenda + graphical abstract)
3. [Divider] I. The Problem
4. The Long-Horizon Research Loop
5. Context Rot: When History Hurts
6. [Divider] II. Three Ideas RAR Combines
7. Recursive Language Models: The Prompt as Environment
8. AutoResearch: Propose, Train, Evaluate, Ratchet
9. GraphRAG: Memory as a Graph, Not a List
10. [Divider] III. Inside RAR
11. Three Layers, One Loop
12. Compressing Context Without Losing the Record
13. The Knowledge Map in Practice
14. A Bounded-Cost Guarantee
15. [Divider] IV. Testing RAR
16. The Experiment: Tuning a Neural Network Under Budget
17. Three Conditions, Head-to-Head
18. Result: Equal Accuracy, 70% Fewer Tokens
19. Density: Only RAR Stays Below the Rot Threshold
20. Ablation: Compression Does the Work
21. Replication on Real Data — and One Honest Failure
22. [Divider] V. An Honest Negative Result
23. Measuring Context Rot, Cycle by Cycle
24. A Metric That Rewards Forgetting
25. Limitations and the Decisive Next Test
26. Conclusion: What Was Proven, What Wasn't

Read titles alone top to bottom — tells the whole story: setup -> concepts -> architecture -> test -> honest result -> conclusion. Good.

## Figures used (from repo, copied to assets/)
graphical_abstract.png, fig1_architecture.png, fig5_degradation.png, fig9_reductions.png,
fig4_ablation_bar.png, fig_digits_reductions.png, fig_digits_accuracy_box.png, fig_rot_trajectory.png
(all white-bg matplotlib/tikz charts — display on white cards)
